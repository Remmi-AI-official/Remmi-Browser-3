package com.remmi.browser

import android.app.Application
import android.util.Log
import coil3.ImageLoader
import coil3.SingletonImageLoader
import coil3.request.crossfade
import com.remmi.adblock.AdblockBridge
import com.remmi.browser.engine.GeckoEngineManager
import com.remmi.browser.security.CurrentTorRoute
import com.remmi.browser.security.NetworkRouteAuthority
import com.remmi.browser.storage.RemmiDatabase
import com.remmi.browser.storage.SettingsRepository
import okhttp3.Call
import java.io.File
import java.util.concurrent.Executors

class RemmiApp : Application(), SingletonImageLoader.Factory {

  override fun newImageLoader(context: coil3.PlatformContext): ImageLoader {
    val callFactory = Call.Factory { request ->
      val targetUrl = request.url.toString()
      val isGhost = CurrentTorRoute.isGhostActive || NetworkRouteAuthority.isOnionDestination(targetUrl)
      try {
        val client = NetworkRouteAuthority.createHttpClient(
          isGhost = isGhost,
          targetUrl = targetUrl,
          connectTimeoutSeconds = 10L,
          readTimeoutSeconds = 15L
        )
        val updatedRequest = request.newBuilder().apply {
          if (request.header("User-Agent") == null) {
            header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36")
          }
          if (request.header("Accept") == null) {
            header("Accept", "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8")
          }
        }.build()
        client.newCall(updatedRequest)
      } catch (e: Exception) {
        throw java.io.IOException("Route authority rejected Coil fetch: ${e.message}", e)
      }
    }

    return ImageLoader.Builder(context)
      .components {
        add(coil3.network.okhttp.OkHttpNetworkFetcherFactory(callFactory = callFactory))
      }
      .crossfade(true)
      .build()
  }

  private fun isMainProcess(): Boolean {
    val processName = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
      getProcessName()
    } else {
      try {
        File("/proc/self/cmdline").readText().trim().trim(0.toChar())
      } catch (_: Exception) {
        val pid = android.os.Process.myPid()
        val am = getSystemService(android.content.Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
        am?.runningAppProcesses?.firstOrNull { it.pid == pid }?.processName
      }
    }
    return processName == null || processName == packageName
  }

  override fun onCreate() {
    super.onCreate()

    if (!isMainProcess()) {
      Log.i("RemmiApp", "Skipping application onCreate for child/isolated process: ${if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) getProcessName() else "child"}")
      return
    }

    // 1. Earliest process start & abnormal termination journal check
    com.remmi.browser.util.DebugLogManager.init(this)
    com.remmi.browser.util.CrashHandlerHelper.onProcessStart(this)
    com.remmi.browser.util.HangWatchdog.startMainThreadWatchdog()
    com.remmi.browser.util.ProcessMemoryTelemetry.init(this)
    com.remmi.browser.util.ProcessMemoryTelemetry.startSampling()

    // 2. Global Uncaught Exception Handler to capture crash diagnostics privately
    com.remmi.browser.util.CrashHandlerHelper.install(this)

    com.remmi.browser.storage.SqlCipherInitializer.ensureLoaded()
    com.remmi.browser.util.CrashHandlerHelper.updateStartupPhase(this, com.remmi.browser.util.StartupPhase.APPLICATION_CREATED)

    // Initialize local storage and settings in background to keep startup instant
    val executor = Executors.newSingleThreadExecutor { r ->
      Thread(r, "RemmiApp-Init").apply {
        isDaemon = true
        priority = Thread.MIN_PRIORITY
      }
    }
    executor.execute {
      try {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
        Log.i("RemmiApp", "Background initialization started...")
        val bridge = AdblockBridge.getInstance()
        bridge.initEngine()
        RemmiDatabase.bootstrap(this)
        SettingsRepository.getInstance(this)
        
        // Priority 1: Pre-warm GeckoRuntime asynchronously on cold start (<1s startup)
        GeckoEngineManager.getInstance(this@RemmiApp).prewarm()

        // Priority 2: Stagger adblock compilation in low priority background
        val filterManager = com.remmi.adblock.FilterManager.getInstance(this, bridge)
        kotlinx.coroutines.runBlocking {
          try {
            filterManager.ensureFiltersReady()
          } catch (e: Throwable) {
            Log.w("RemmiApp", "[ADBLOCK] Background filter bootstrap error: ${e.message}")
          }
        }
        Log.i("RemmiApp", "Background initialization completed.")
      } catch (e: Throwable) {
        Log.e("RemmiApp", "Error during background init: ${e.message}", e)
      }
    }
  }

  override fun onTrimMemory(level: Int) {
    super.onTrimMemory(level)
    try {
      com.remmi.browser.engine.TabThumbnailManager.getInstance(this).onTrimMemory(level)
      com.remmi.browser.engine.GeckoEngineManager.getInstance(this).onTrimMemory(level)
    } catch (_: Throwable) {}
  }

  override fun onLowMemory() {
    super.onLowMemory()
    try {
      com.remmi.browser.engine.TabThumbnailManager.getInstance(this).onLowMemory()
      com.remmi.browser.engine.GeckoEngineManager.getInstance(this).onLowMemory()
    } catch (_: Throwable) {}
  }
}

